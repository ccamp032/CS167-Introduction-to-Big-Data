# Lab 6

## Student information
* Full name: Christian Campos
* E-mail: ccamp032@ucr.edu
* UCR NetID: ccamp032
* Student ID: 862080812

## Questions

(Q) What is the type of the attributes time and bytes this time? Why?
```
Time and bytes became string datatypes because option("inferSchema", "true") will parse the time and bytes as an integer.

```