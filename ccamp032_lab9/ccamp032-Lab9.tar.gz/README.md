# Lab 9

## Student information
* Full name: Christian Campos
* E-mail: ccamp032@ucr.edu
* UCR NetID: ccamp032
* Student ID: 862080812

I didn't do the bonus points part so I didn't answer the questions.
