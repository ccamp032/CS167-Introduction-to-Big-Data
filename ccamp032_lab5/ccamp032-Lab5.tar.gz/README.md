# Lab 5

## Student information
* Full name: Christian Campos
* E-mail: ccamp032@ucr.edu
* UCR NetID: ccamp032
* Student ID: 862080812

## Questions
(Q) What are these two arguments?
```
It could any one of the commands listed in the switch cases in the program.
Then follow by an input file. 
The input file is one of the two sample files.

```